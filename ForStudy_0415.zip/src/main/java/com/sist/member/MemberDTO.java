package com.sist.member;

public class MemberDTO {
	private String id;
	private String pwd;
	private String nick;
	private String email;
	private int m_agree;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getM_agree() {
		return m_agree;
	}
	public void setM_agree(int m_agree) {
		this.m_agree = m_agree;
	}
	
	
		
}
