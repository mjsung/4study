$('.searchButton').on('click',function(){
  alert('You clicked search button');
});