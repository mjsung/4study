A Pen created at CodePen.io. You can find this one at http://codepen.io/engza/pen/Btedl.

 This is a simple way of embedding a Google Map with multiple markers. You can add more markers, change the map size, zoom level, center of the map, etc. If you have any questions, feel free to contact me.