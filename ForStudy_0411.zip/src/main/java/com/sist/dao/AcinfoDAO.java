package com.sist.dao;

import java.sql.*;
import java.util.*;

public class AcinfoDAO {
   private Connection conn;
   private PreparedStatement ps;
   private ResultSet rs;
   private final String URL = "jdbc:oracle:thin:@211.238.142.40:1521:ORCL";
   private static AcinfoDAO dao;

   public AcinfoDAO(){
      try{
         Class.forName("oracle.jdbc.driver.OracleDriver");
      }catch(Exception ex){
         System.out.println("AcinfoDAO() 생성자 에러 : "+ex.getMessage());
      }
   }

   public void getConnection(){
      try{
         conn = DriverManager.getConnection(URL, "scott", "tiger");
      }catch(Exception ex){
         System.out.println("getConntection() 에러 : "+ex.getMessage());
      }
   }

   public void disConnection(){
      try{
         if(ps != null) ps.close();
         if(conn != null) conn.close();
      }catch(Exception ex){
         System.out.println("disConnection() 에러 : "+ex.getMessage());
      }
   }

   public static AcinfoDAO newInstance(){
      if(dao == null)
         dao = new AcinfoDAO();
      return dao;
   }

   public List<AcinfoDTO> allData(){
      List<AcinfoDTO> list = new ArrayList<AcinfoDTO>();
      try {
         getConnection();
         String sql = "SELECT ac_no "
         				  + ",ac_name "
         				  + ",ac_address"
         				  + ",ac_class"
         				  + " FROM ac_info "
         				  + " WHERE ROWNUM<20";
         ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery();
         while(rs.next()){
            AcinfoDTO d = new AcinfoDTO();
            d.setAc_address(rs.getString(1));
            list.add(d);
         }
         rs.close();
      }catch(Exception ex){
         System.out.println("allData() 에러 : " + ex.getMessage());
      }finally{
         disConnection();
      }
      return list;
   }
   public List<AcinfoDTO> AcinfoSearch(String search){
		List<AcinfoDTO> list = new ArrayList<AcinfoDTO>();
		try{
			getConnection();
				
				search.trim();
				StringTokenizer st=new StringTokenizer(search);
				
				String data[]=new String[st.countTokens()];
				for(int i=0;i<data.length;i++){
					data[i]=st.nextToken();
					//System.out.println(data[i]);
				}
				
				//String search="AND ((ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%')
				String sql="SELECT distinct(ac_name),ac_address,ac_class,ac_tel FROM ac_info "
						+ "WHERE (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
				
				
				int j=0;
				while(j<data.length-1){
					sql+="AND (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
					j++;
				}
			
				ps=conn.prepareStatement(sql);
				for(int i=0;i<data.length*3;i++){
					ps.setString(i+1,"%"+data[i/3]+"%");
				}
				rs=ps.executeQuery();
			

				while (rs.next()) {
				AcinfoDTO d = new AcinfoDTO();
				d.setAc_name(rs.getString(1));
				d.setAc_address(rs.getString(2));
				d.setAc_class(rs.getString(3));
				d.setAc_tel(rs.getString(4));
				list.add(d);
			}
				
			rs.close();
			//System.out.println(search);
		}catch(Exception ex){System.out.println(ex.getMessage());}
		
		finally{
			disConnection();
		}
		return list;
   }
   public int AcinfoTotal(String search) {
		int total = 0;
		try {
			getConnection();
			search.trim();
			StringTokenizer st=new StringTokenizer(search);
			String data[]=new String[st.countTokens()];
			for(int i=0;i<data.length;i++){
				data[i]=st.nextToken();
			}
			String sql="SELECT CEIL(COUNT(*)/10) FROM "
					+ "(SELECT distinct ac_name,ac_address,ac_tel FROM "
					+ "(SELECT distinct ac_name,ac_address,ac_class,ac_tel,ac_no,rownum as num FROM "
					+ "(SELECT distinct ac_name,ac_address,ac_class,ac_tel,ac_no FROM ac_info "
					+ "WHERE (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
			
			
			int j=0;
			while(j<data.length-1){
				sql+="AND (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
				j++;
			}
				sql+="ORDER BY ac_no DESC )))";
			ps = conn.prepareStatement(sql);
			for(int i=0;i<data.length*3;i++){
				ps.setString(i+1,"%"+data[i/3]+"%");
			}
			rs = ps.executeQuery();
			rs.next();
			total = rs.getInt(1);
			rs.close();
		} catch (Exception ex) {
			System.out.println("BoardTotal메소드"+ex.getMessage());
		} finally {
			disConnection();
		}

		return total;

	}
   public List<AcinfoDTO> AcinfoSearchPage(String search,int page){
		List<AcinfoDTO> list = new ArrayList<AcinfoDTO>();
		try{
			getConnection();
				
				search.trim();
				int rowSize = 10;
				int start = (rowSize * page) - (rowSize - 1);
				int end = rowSize * page;
				
				StringTokenizer st=new StringTokenizer(search);
				
				String data[]=new String[st.countTokens()];
				for(int i=0;i<data.length;i++){
					data[i]=st.nextToken();
					//System.out.println(data[i]);
				}
				
				String sql="SELECT distinct ac_name,ac_address,ac_tel,num FROM "
				+ "(SELECT distinct ac_name,ac_address,ac_tel,rownum as num FROM "
				+"(SELECT distinct ac_name,ac_address,ac_tel FROM ac_info " 
				+"WHERE (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
				
				/*SELECT distinct ac_name,ac_address,ac_tel,num FROM(
	SELECT distinct ac_name,ac_address,ac_tel,rownum as num FROM(SELECT distinct ac_name,ac_address,ac_tel FROM ac_info 
	WHERE (ac_address like '%신촌%' OR ac_class LIKE '%신촌%' OR ac_name LIKE '%신촌%')
	)) WHERE num BETWEEN 1 AND 100 ORDER BY num ASC;*/
				
				//String search="AND ((ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%')
				/*String sql="SELECT distinct(ac_name),ac_address,ac_class,ac_tel FROM ac_info "
					+ "WHERE (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";*/
				
				
				int j=0;
				while(j<data.length-1){
					sql+="AND (ac_address like '%'||?||'%' OR ac_class LIKE '%'||?||'%' OR ac_name LIKE '%'||?||'%') ";
					j++;
				}
				
				sql+=")) WHERE num BETWEEN " +start+ " AND " +end+" ORDER BY num ASC";
			
				ps=conn.prepareStatement(sql);
				for(int i=0;i<data.length*3;i++){
					ps.setString(i+1,"%"+data[i/3]+"%");
				}
				rs=ps.executeQuery();
				
				while (rs.next()) {
						
						
						AcinfoDTO d = new AcinfoDTO();
						d.setAc_name(rs.getString(1));
						d.setAc_address(rs.getString(2));
//						d.setAc_class(rs.getString(3));
						d.setAc_tel(rs.getString(3));
//						d.setAc_no(rs.getInt(5));
						list.add(d);
						
						
			}
				
			rs.close();
			//System.out.println(search);
			System.out.println(sql);
		}catch(Exception ex){
			System.out.println("search:"+ex.getMessage());
		}
		
		finally{
			disConnection();
		}
		return list;
  }
}
   